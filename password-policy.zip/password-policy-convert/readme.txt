=== Password-policy ===
Contributors: Mehdi Aberkane
Tags: password, policy, enhance, security
Requires at least: 4.0
Tested up to: 5.4
Stable tag: 0.1
License: GPLv2 or later

A plugin wordpress for enhance the password policy.

== Description ==

A plugin wordpress for enhance the password policy.

Major features in Password-policy include:

* Disable confirm Use of Weak Password checkbox for users.
* Enhance the password policy with multiple options
* Force reset all password users

== Installation ==

Upload the Password-policy plugin to your blog, activate it, and enjoy.

== Changelog ==

= 0.1 =
*Release Date - 06 Mai 2020*

* Init project.
* Disable confirm Use of Weak Password checkbox for users.
* Enhance the password policy with multiple options

= 0.2 =
*Release Date - 20 jun 2020*

